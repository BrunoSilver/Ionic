import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-codebar',
  templateUrl: './codebar.page.html',
  styleUrls: ['./codebar.page.scss'],
})
export class CodebarPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
